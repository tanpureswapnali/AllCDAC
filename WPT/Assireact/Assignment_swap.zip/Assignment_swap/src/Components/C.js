function C(){
   return <div>This is Component C
    
   </div>

}

 

export default C;