import B from "./B.js"
import C from "./C.js"

function A(){
   return <div>
    <h5>This is A component</h5>
   <B/>
   </div>
}

export default A;