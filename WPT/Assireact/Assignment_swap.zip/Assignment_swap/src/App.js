//import Addition from "./Swapnali/Addition.js"
//import Substraction from "./Swapnali/Substraction.js";
//import Multiplicat from "./Swapnali/Multiplicat.js"
//import Division from "./Swapnali/Division.js"
import Mod from "./Swapnali/Mod.js"
//import FruitList from "./Swapnali/FruitList.js";
//import MovieList from "./Swapnali/MovieList.js"
function App(){
  return <div>
    <h2>Assignment</h2>
   {/* <Addition/><FruitList></FruitList><MovieList></MovieList> <Substraction></Substraction > <Division></Division> <Multiplicat></Multiplicat>*/} 
  <Mod></Mod>
   
  </div>
}




export default App;