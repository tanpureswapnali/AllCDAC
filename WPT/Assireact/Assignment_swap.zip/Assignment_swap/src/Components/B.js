//import C from "./C.js"

function B(){
   return  <div> 
    <p>
    This is component B
    </p>
    {/*<C/>*/}
    </div>
}



export default B;